print("Ecommerce Initialized")
